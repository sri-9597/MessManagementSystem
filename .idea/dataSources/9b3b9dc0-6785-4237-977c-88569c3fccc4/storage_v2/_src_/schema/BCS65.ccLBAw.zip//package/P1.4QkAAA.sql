create PACKAGE P1 AS 
  x number;
  y number;
  procedure add3(a in number,b in number,d in number,c out number);
  function sqr(a number) return number;
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

END P1;
/

