create package body complex_number as
 
	procedure mul(a1 in integer,b1 in integer,a2 in integer,b2 in integer,a3 out integer,b3 out integer) is

	begin 
	a3 := a1*a2 - b1*b2;
	b3 := a1*b2 + a2*b1;
        dbms_output.put_line(a3);
	dbms_output.put_line(b3);
	end;

begin

dbms_output.put_line('initialization code');
end complex_number;
/

