create package body P1 as
z number;
procedure add3( a in number,b in number,d in number,c out number ) is
e number;
begin 
c := a+b+d;
end;
function sqr (a number) return number is
begin
return (a*a);
end;
begin
x:=67;
y:=80;
z:=0;
dbms_output.put_line('initialization code');
end P1;
/

