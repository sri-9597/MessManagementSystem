CREATE PACKAGE complex_number AS 
  a1 integer;
  b1 integer;
  a2 integer;
  b1 integer;
  procedure mul(a1 in integer,b1 in integer,a2 in integer,b2 in integer,a3 out integer,b3 out integer);

END complex_number;
/

